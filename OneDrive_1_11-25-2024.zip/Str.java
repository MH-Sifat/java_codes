public class Str {
    public static void main(String[] args) {
        String str = "Hello, world!";
        
        //  index of a character
        System.out.println(str.indexOf('o'));          
		
        
        // index of a character from a specified index
        System.out.println(str.indexOf('o', 5));        
		// Output: 8 (second 'o' in "world")
        
        // a substring
        System.out.println(str.indexOf("world"));       
		// Output: 7
        
        // Find the index of a substring from a specified index
        System.out.println(str.indexOf("o", 9));      
		// Output: -1 (no 'o' after index 9)
    }
}
