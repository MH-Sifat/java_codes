public class Test11{
	public static void main(String args[]){
		student2 s1= new student2(201,"Ebrahim");
		s1.display();
		student2 s2= new student2(202,"Rahim");
		s2.display();
}}
		