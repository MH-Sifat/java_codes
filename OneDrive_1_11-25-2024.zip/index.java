import java.lang.*;
//indexOf()
class index{
public static void main(String args[]){
	String r= new String("Hello, World!");
	//index of a character
	System.out.println(r.indexOf('o'));
	
	//index of character from a specific index
	System.out.println(r.indexOf('l',4));
	//index of substring return
	System.out.println(r.indexOf("ld"));
	String str="Raima Adhikary";
	System.out.println(str.indexOf('h'));
	
	
}}