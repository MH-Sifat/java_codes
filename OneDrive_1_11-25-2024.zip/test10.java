public class test10{
public static void main(String args[]){
	BankAccountt b1=new BankAccountt();// b1 sender
	b1.setAccountNo(10101);
	b1.setAccountHolder("Rahman anik");
	b1.setBalance(4000.00);
	System.out.println("Account Number is: "+b1.getAccountNo());
	System.out.println("Account holder name is: "+b1.getAccountHolder());
System.out.println("Balance is: "+b1.getBalance());

BankAccountt b2=new BankAccountt(10102,"Akbar Rahim",3500.00);
b2.showDetails();// receiver
b1.sendMoney(b2,500.0);
System.out.println("Balance of sender: " +b1.getBalance());
System.out.println("Balance of receiver: " +b2.getBalance());}}


	
