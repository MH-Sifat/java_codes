// Sample Question
//Q1.identify which one is method and which one is constructor?
//Q2.What will be the output?
public class car{
private static int count=0;
public car(){
count++;}
public static int getcount(){
return count;}
public static void main(String args[]){
car c1=new car();
System.out.println("Number of car instances: "+car.getcount());
car c2=new car();
System.out.println("Number of car instances: "+car.getcount());
car c3=new car();
System.out.println("Number of car instances: "+car.getcount());}}
