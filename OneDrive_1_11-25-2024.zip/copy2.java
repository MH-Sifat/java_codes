//copy constructor 

// optional_modifier constructor_copy
//(original_construcor (as a type) var_name)

class copy2{
int i;
String n;
public copy2(int i, String n){
	this.i=i;// instance variable= local variable
this.n=n;}
public copy2(copy2 c){
this.i=c.i;
this.n=c.n;
}
void display(){
System.out.println(i+" "+n);}
public static void main(String args[])
{
	copy2 cw=new copy2(12, "Kabir");
	copy2 cy= new copy2(cw);
	cw.display();
cy.display();}}
	



