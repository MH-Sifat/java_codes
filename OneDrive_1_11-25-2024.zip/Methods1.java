public class Methods1{

public static void main(String args[]){
Methods1 m1=new Methods1();
System.out.println("The sum is: "+m1.add(12,13));
System.out.println("The sub is: "+sub(30,7));
}

int s;// instance variables
float d;// class variables
double r;//  class variables
public int add(int a, int b){
	s= a+b;// a and b will be local variables
	return s;	
}
public static int sub(int a, int b){
	return a-b;
	
}
	static{
		System.out.println("Hello Static");
		
	}
}
// create a method div and remainder if denominator is 0
//division is not possible and implement the class
