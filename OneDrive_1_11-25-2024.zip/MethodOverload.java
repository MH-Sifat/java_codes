
public class MethodOverload {
    public static int area(int side) {
        //calculates and returns the area of square
        return side * side;
    }
    public static int area(int side1, int side2) {
        //calculates and returns the area of rectangle
        return side1 * side2;
    }

    public static void main(String[] args) {
        System.out.println("area() with 1 parameter");
        System.out.println("Area of Circle: "+area(5)+" square units");
        System.out.println("area() with 2 parameters");
        System.out.println("Area of Rectangle: "+area(5, 2)+" square units");
    }
}