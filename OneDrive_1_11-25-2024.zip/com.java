public class com {
    public static void main(String[] args) {
        String str1 = "apple";
        String str2 = "banana";
        String str3 = "apple";

        System.out.println(str1.compareTo(str2)); 
		// Negative, because "apple" comes before "banana"
        System.out.println(str1.compareTo(str3)); 
		// Zero, because both strings are equal
        System.out.println(str2.compareTo(str1)); 
		// Positive, because "banana" comes after "apple"
    }
}
