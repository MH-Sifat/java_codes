// extends keyword
// making an array
import java.lang.*;
class Average{
	public static void main(String args[]){
		double num[]={10.1, 12.4, 16.8, 10};
		double result=0.0;
		for(int i=0;i<4;i++){
		result=result+num[i];}
System.out.println(result);}}
