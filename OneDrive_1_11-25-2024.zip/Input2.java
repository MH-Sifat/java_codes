//task 02: take different kinds of input using Scanner & use methods
//Person's name-String 
//Person's Salary- Double
//Person's age- int 
//Person's phone- long
//person's ID -String
import java.util.Scanner;
class employee{
	String name, gender, position;
	int ID;
	byte age;
	double salary;
	void displayInfo(){
		System.out.println("The name:"+name);
		System.out.println("The gender:"+gender);
System.out.println("The ID:"+ID);}}
public class Input2{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		employee emp=new employee();
		emp.name=sc.nextLine();
		//sc.next();
		emp.gender=sc.nextLine();
		emp.ID= sc.nextInt();
		emp.salary=sc.nextDouble();
emp.displayInfo();
}}
		
		
	
		
