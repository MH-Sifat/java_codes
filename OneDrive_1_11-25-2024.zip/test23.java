import java.util.Scanner;

class Box3{
double length;
double width;
double depth;}

public class test23{
public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	Box3 obj= new Box3();
	obj.length= sc.nextDouble();
	obj.width=sc.nextDouble();
	obj.depth=sc.nextDouble();
	//double volume=obj.length*obj.depth*obj.width;
	//System.out.print(volume);
}}
