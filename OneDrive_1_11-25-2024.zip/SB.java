public class SB{
	//default constructor
public SB(){
System.out.println("Inside Default Constructor");
}
//static block
static{
	int a=20;
	System.out.println(a);
	System.out.println("Inside the static block: -1");
}
static{
	int b=200;
	System.out.println(b);
	System.out.println("Inside the static block: -2");
}
//user defined method 
public void demo(){
System.out.println("Inside demo method");}
public static void main(String args[]){
	SB s1=new SB();// creating an object  and call a default constructor
	s1.demo();//invoking the method through object
	
}}

