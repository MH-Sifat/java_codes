//method overloading 
// syntax : use the same name of method multiple times inside a class.
public class Method3{
	public static int area(int side){
		return side*side;}
		public static int area(int side1, int side2){
		return side1*side2;}
	public static void main(String args[]){
		System.out.println("Area 1 is:" +area(4));
		System.out.println("Area 1 is:" +area(5,7));
		
		
}}
		
		