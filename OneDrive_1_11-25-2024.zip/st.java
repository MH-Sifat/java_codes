import java.lang.*;
class st{
	public static void main(String args[]){
	//explicit	
String s1=new String("Java class");
System.out.println(s1);//string object
System.out.println(s1.length());

//implicit
String Uni="AIUB";//string literal
System.out.print(Uni);
String s3=Uni;
//string reference
System.out.print(s3);
int age= 20;
String msg="I am "+ age+" years old";
System.out.println(msg);

}}
