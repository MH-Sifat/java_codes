// string operation 
import java.lang.*;// all classes import
class string12{
	public static void main(String args[]){
		String s0=new String();// empty string
		String s11= new String("Java Class");// string objects
		int age=25;
		String msg="she is "+ age+" years old";
		String s12=" PRogramming";// implicit // string literal
System.out.println(s11);
System.out.println(s12);
System.out.println(msg);
// isEmpty() method checks whether you have entered any string or not
System.out.println(s0.isEmpty());
System.out.println(s11.isEmpty());
System.out.println(s12.isEmpty());
// length() methodSystem.out.println(s0.isEmpty());
System.out.println(s11.length());
System.out.println(s12.length());
//charAt()
System.out.println(s11.charAt(3));
System.out.println(msg.charAt(3));













}}
