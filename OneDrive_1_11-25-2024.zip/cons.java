public class BankAccount {
    String ownersName;
    int accountNumber;
    float balance;

    // Default constructor
    public BankAccount() {
        this.ownersName = "Unknown";
        this.accountNumber = 0;
        this.balance = 0.0f;
    }
    // Constructor with account number
    public BankAccount(int anAccountNumber) {
        accountNumber = anAccountNumber;
        this.ownersName = "Unknown";
        this.balance = 0.0f;
    }

    // Constructor with account number and owner's name
    public BankAccount(int anAccountNumber, String aName) {
        accountNumber = anAccountNumber;
        ownersName = aName;
        this.balance = 0.0f;
    }

    // Method to deposit money
    public void deposit(float amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    // Method to check the balance
    public float getBalance() {
        return balance;
    }

    // Method to display account details
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Owner's Name: " + ownersName);
        System.out.println("Balance: " + balance);
    }
}
public class cons{
    public static void main(String[] args) {
        // Create a new bank account
        BankAccount myAccount = new BankAccount(123456, "John Doe");

        // Display account information
        myAccount.displayAccountInfo();

        // Deposit money into the account
        myAccount.deposit(500.0f);
        System.out.println("Balance after deposit: " + myAccount.getBalance());

        // Attempt to deposit a negative amount
        myAccount.deposit(-100.0f);

        // Final balance
        System.out.println("Final balance: " + myAccount.getBalance());
    }
}

