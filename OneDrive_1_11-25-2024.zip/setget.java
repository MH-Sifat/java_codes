// use of setter and getter methods
//public void setMethod(int a){//reassignment;}
//public return_type getMethod(){ return variable_name;}
class cube{
	private double length;
	private double width;
	private double height;
	public void setLength(double l){
	this.length=l;}
	public void setWidth(double w){
	this.width=w;}
	public void setHeight(double h){
	this.height=h;}
	public double getLength(){
	return this.length;}
		public double getWidth(){
	return this.width;}
		public double getHeight(){
return this.height;}}
public class setget{
	public static void main(String args[]){
		cube c1=new cube();
		c1.setLength(2.389);
		c1.setWidth(5.475);
		c1.setHeight(3.21);
		System.out.println("The length is:"+c1.getLength());
		System.out.println("The Width is:"+c1.getWidth());
System.out.println("The Height is:"+c1.getHeight());}}
		
		
		
		
		
		
		
		
	
	
	
	