//lab task -
//create one or more classes to implement 
//Take employee name- string
//employee ID - string
//Employee  gender- String
//employee salary float
//employee phone long
//employee age byte

import java.util.Scanner;
import java.util.*;
class Box4{
double length;
double width;
double height;}

public class test4{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);	
Box4 ob=new Box4();
ob.length=sc.nextDouble();
ob.width=sc.nextDouble();
ob.height=sc.nextDouble();
double volume=ob.length*ob.width*ob.height;
System.out.print("The result is: "+volume);}}


