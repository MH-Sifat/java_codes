public class Method1
{  
public static void main(String [] args)  
{  
Method1 obj = new Method1();    
System.out.println("The sum is: "+obj.add(12, 13)); 
 System.out.println("The division is: "+obj.div(120, 13)); 

 System.out.println("The remainder is: "+obj.rem(1200, 12));
 }  
int s; //local variable
float d;
float r; 
//saMPLE:
public int add(int a, int b)  
{  
s = a+b;  
return s;  }
public float div(int a, int b)  
{  
d = a/b; 
//r=a%b; 
return d;
 }
 public float rem(int a, int b)  
{  

r=a%b; 
return r;
}
}
//create an instance method to return the value of quotient 
//and remainder .
//add a condition if denominator is 0 -> division is not possible.