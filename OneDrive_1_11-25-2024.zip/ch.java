import java.lang.*;
import java.util.Scanner;
class ch{
public static void main(String args[]){
	Scanner input=new Scanner(System.in);
	char c=input.next().charAt(0);
	//charAT(0)
	if(c>='a' && c<='z')
	{System.out.println("User entered a small letter");}
	else if(c>='A' && c<='Z')
	{System.out.println("User entered a capital letter");}
	else
	{System.out.println("Not letter");}
	//input.close();

}}
		
