public class StaticBlock1  
{  
  public StaticBlock1()   
{  
System.out.println("Inside the constructor of the class.");  
}  
  
// 1st SB 
static  
{  
System.out.println("Inside the static block. - 1");   
}  
  
// demo() method of the StaticBlock class  
public static void demo()   
{  
System.out.println("Inside the method foo.");  
}  
  
// 2nd static block  
static  
{  
System.out.println("Inside the static block. - 2");   
}  
  
// 3rd static block  
static  
{  
System.out.println("Inside the static block. - 3");   
}  
  
// main method  
public static void main(String[] args)   
{  
  
// instantiating the class StaticBlock1  
StaticBlock1 sbObj = new StaticBlock1();  
sbObj.demo(); // invoking the method  
  
// invoking the constructor inside the main() method  
new StaticBlock1();  
  
}  
}  