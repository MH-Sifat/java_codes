//setter and getter methods 
// a new way of reassigning
import java.util.*;
import java.lang.*;
public class Box5{
	private double length;
	private double width;
	private double height;
	public void setLength(double l){
	this.length=l;}
	public void setWidth(double w){
	this.width=w;}
	public void setHeight(double h){
	this.height=h;}
	
	public double getLength(){
	return length;}
	
	public double getWidth(){
	return width;}
	public double getHeight(){
	return height;}
	public static void main(String args[]){
		Box5 b=new Box5();
		b.setLength(2.50);
		b.setWidth(5.34);
		b.setHeight(6.20);
		System.out.println("Length is:"+b.getLength());
		System.out.println("Width is:"+b.getWidth());
System.out.println("height is:"+b.getHeight());}}
		
	
	
