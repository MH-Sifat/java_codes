class B
{public static void main(String args[]){
byte b=50;
b=(int)((byte)b*50);
//int c;
//c=(int)b*50;
System.out.println(b);}}