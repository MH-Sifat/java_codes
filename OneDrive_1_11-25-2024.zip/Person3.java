// designing constructor
public class Person3{
	private String name;// class variables, instance variabl;e
	private int ID;// class variables
	Person3(){
	System.out.print("Default");}
	Person3(String n){
		//reassignment
		name=n;	
	}
	Person3(String n, int i){
	name=n;
ID=i;}
void display(){
	System.out.println("Name is "+name);
System.out.println("ID is "+ID);}
public static void main(String args[]){
	Person3 p1=new Person3("Saima");
p1.display();
Person3 p2=new Person3();
p2.display();}}
	
	