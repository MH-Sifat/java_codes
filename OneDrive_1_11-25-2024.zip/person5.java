class person5{
private String name;
private int age;
public void setName(String n){
this.name=n;}
public String getName(){
return this.name;}
public void setAge(int age){
	if(age>0)
		this.age=age;
	else
System.out.println("invalid age");}
public int getAge(){
return this.age;}
}


