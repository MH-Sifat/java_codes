import java.lang.*;
class string11{
	public static void main(String args[]){
		String st= new String("Hello World");// string object
		//string literal 
		int age= 25;
		String msg="I am "+age+" years old";
		System.out.println(st);
		System.out.println(st.length());//method invoke
		
	System.out.println(msg.length());
	String r=new String();
System.out.println(r.isEmpty());
System.out.println(st.isEmpty());
//charAt()
String str="Java Class";
int index1=str.charAt(1);
int index2=str.charAt(6);
int index3=str.charAt(8);
System.out.println((char)index1+" "+(char)index2+" "+(char)index3);
}}
		
