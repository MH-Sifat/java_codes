//copy constructor 

// optional_modifier constructor_name(constructor_name var_name){
//}
class copy1{
	
		int i;
		String n;
		public copy1(int i, String n){
			this.i=i;// instance variable= local variable
		this.n=n;}
		public copy1(copy1 c)
		{
			i=c.i;
			n=c.n;
		}
		void display1(){ System.out.println(i+" "+n);}
		public static void main(String args[]){
			copy1 cp=new copy1(12,"Kabir");
			copy1 ct= new copy1(cp);
			cp.display1();
ct.display1();}}
			
		
		