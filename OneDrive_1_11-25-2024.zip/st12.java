// whether user has entered a small letter or capital by charAT()

import java.lang.*;
import java.util.Scanner;
class st12{
public static void main(String args[]){
Scanner sc= new Scanner(System.in);
char ch= sc.next().charAt(0);
if( ch>='a' && ch<='z')
	System.out.println("Small letter");
else if(ch>='A' && ch<='Z')
	System.out.println("Capital letter");
else 
	System.out.println("invalid");


}}
	

