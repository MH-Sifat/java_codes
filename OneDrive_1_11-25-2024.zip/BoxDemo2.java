import java.util.Scanner;

class Box {
    double width;
    double height;
    double depth;
}

public class BoxDemo2 {
    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        Box obj = new Box();
        double volume;
		System.out.print("Enter width: ");
        obj.width = scanner.nextDouble();

        System.out.print("Enter height: ");
        obj.height = scanner.nextDouble();

        System.out.print("Enter depth: ");
        obj.depth = scanner.nextDouble();

        
        volume = obj.width * obj.height * obj.depth;

        System.out.println("Volume is: " + volume + " cubic units");
	}
    }
