import java.util.Scanner;
class input3{
	public static void main(String args[]){
		Scanner in=new Scanner(System.in);
		double number[]=new double[5];
		//type arr_name[]=new type[size]
		for(int i=0;i<number.length;i++){
			System.out.println("enter your elements");
number[i]=in.nextDouble();}
for(int i=0;i<number.length;i++){
			System.out.println(" "+number[i]+" ");
}


}}