//static method
// classname.static_method_name
class Test12{
	public int add(int a, int b){
	return a+b;
}
public static int multiply(int a, int b){
return a*b;}
public static void main(String args[]){
Test12 t1=new Test12();
int result= t1.add(23, 10);
System.out.println(result);

int result2=Test12.multiply(4,5);
System.out.println(result2);
}}


