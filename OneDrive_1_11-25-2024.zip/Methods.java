//task 01: To make a method 
class Methods{
	double salary=23789.500;
	byte age=23;
	String name="Fariha";
	void display(){
	System.out.println(age+" "+salary+" "+name);}
	public static void main(String args[]){
		Methods ob= new Methods();
ob.display();
}}
	