//Method Overloading

class method2{
public static int sub(int a, int b){
return a-b;}
public static int sub(int a, int b, int c){
return a+b-c;}
public static void main(String args[]){
System.out.println("Subtraction of two parameters:");
System.out.println(sub(13,8));
System.out.println("Subtraction of three parameters:");
System.out.println(sub(10,20,8));}}


	