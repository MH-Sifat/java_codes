class employee{
    String name, gender, position;
    int ID, age;
    void displayInfo(){
        System.out.println("The name is "+name);
        System.out.println("The gender is "+gender);
        System.out.println("The ID is "+ID); }}
public class test {
    public static void main(String args[])
    {
employee e1= new employee();
e1.name="Raima Adhikary";
e1.gender="female";
e1.ID=2456;
e1.displayInfo();
       // System.out.println("The name is "+e1.name);
        //System.out.println("The gender is "+e1.gender);
      //  System.out.println("The ID is "+e1.ID);


employee e2= new employee();
        e2.name="Raihan Islam";
        e2.gender="male";
        e2.ID=2356;
        e2.displayInfo();
        //System.out.println("The name is "+e2.name);
        //System.out.println("The gender is "+e2.gender);
       // System.out.println("The ID is "+e2.ID);

    }
}
