public class Person4{
	private int ID;
	private String name;
	private float salary;
public Person4(){
//System.out.println("Default");	
}// default constructor
public Person4(String n, float s){
	//reassignment
	name=n;
	salary=s;
}
public Person4(String n, float s, int i){
	//reassignment
	name=n;
	salary=s;
	ID=i;
}
void display(){
	System.out.println("Name: "+name);
	System.out.println("ID "+ID);
System.out.println("Salary "+salary);}
public static void main(String args[]){
	Person4 p1= new Person4("Samiha",245.00F,12);
p1.display();
	Person4 p2= new Person4();//default 
p2.display();
}}
	
	

