//string operations
import java.lang.*;
class string20{
	public static void main(String args[]){
		String s0=new String();//empty string object
		String s11=new String("Hello World");// string object
		String s14=new String("Hello World");
String s12="Hi";// string literal
String s13=s12;//string reference
//equals()

if(s11.equals(s14)){
System.out.println("yes");}
else{System.out.println("no");}

//compareTo()
String s21="America";// 7 characters
String s22="banana";//6 characters
String s23=s22;
System.out.println(s21.compareTo(s22));
System.out.println(s22.compareTo(s21));
System.out.println(s23.compareTo(s22));
//indexOf
String s31=new String("Hello World ");
System.out.println(s31.indexOf('e'));
// index of a character from a specific position
System.out.println(s31.indexOf('l',5));
//beginning index of a substring 
System.out.println(s31.indexOf("World"));
System.out.println(s31.toLowerCase());
System.out.println(s31.toUpperCase());
//trim()
System.out.println(s31.trim());

//substring()
System.out.println(s31.substring(0,3));
System.out.println(s31.substring(7));











}}
		
