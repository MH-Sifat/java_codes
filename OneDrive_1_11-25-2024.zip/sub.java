public class sub {
    public static void main(String[] args) {
        String str = "Hello, world!";
        
        // Extract substring from index 7 to the end
        System.out.println(str.substring(7));      
		// Output: "world!"
        
        // Extract substring from index 0 to index 5 (exclusive)
        System.out.println(str.substring(0, 5));    
		// Output: "Hello"
        
        // Extract substring from index 7 to index 12 (exclusive)
        System.out.println(str.substring(7, 12));     
		// Output: "world"
    }
}
