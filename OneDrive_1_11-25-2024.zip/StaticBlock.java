public class StaticBlock {
 static int staticVariable;
  
    static {
        // Initialize static variable
        staticVariable = 100;
        System.out.println("Static block executed.");
        System.out.println("Static variable initialized to: " + staticVariable);
    } 
	public StaticBlock() {
        System.out.println("Constructor executed.");
    }
 public static void main(String[] args) {
        System.out.println("Main method started.");

    
        StaticBlock obj1 = new StaticBlock();
       StaticBlock obj2 = new StaticBlock();
System.out.println("Static variable after creating objects: " + StaticBlock.staticVariable);
		//classname.static variable name
    }
}
