public class psm {

    static int count = 0;

    public psm() {
        count++;
        System.out.println("Object created. count: " + count);
    }
    // Private static method
    private static void display(String msg) {
        System.out.println("Private static method says: " + msg);
    }

    // Public method to access the private static method
    public static void cp(String msg) {
        // Calling the private static method inside the class
        display(msg);
    } public static void main(String[] args) {
        
        System.out.println("Main method started.");
		cp("Hello from the private static method!");
        
        // Creating an object of the class
        psm obj1 = new psm();
        psm obj2 = new psm();
    }
}
