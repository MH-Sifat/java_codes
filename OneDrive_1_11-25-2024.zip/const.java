// designing constructor
public class Person3{
	private String name;// class variables, instance variabl;e
	private int ID;// class variables
	Person3(){
	System.out.print("Default");}
	Person3(String n){
		//reassignment
		name=n;	
	}