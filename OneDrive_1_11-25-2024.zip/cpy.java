//copy constructor
class student6{
	int ID;
	String name;
	student6(){}
	student6(int i, String n){
		ID=i;//instance variable= local variable
		name=n;//
	}
	student6(student6 s){
		ID=s.ID;//instance variable = local variable 
		name=s.name;
		
}
void display(){
	
System.out.println(ID+" "+name);}
}

public class cpy{
	public static void main(String args[]){
		student6 s1= new student6(111, "Saima");
		student6 s2= new student6(s1);
		s1.display();
s2.display();}}
	
