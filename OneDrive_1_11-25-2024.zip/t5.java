// extends keyword
class Animal{
	String name;
	public void eat(){
System.out.println("I can eat");}}
class cat extends Animal{
	public void display(){
System.out.println("My name is "+name);}}
public class t5{
	public static void main(String args[]){
		cat c1=new cat();
		c1.name="Meow";
c1.display();}}
		
