//creating method and constructors in java
class Teacher{
	String name, gender;
	long phone;
	Teacher(){
	System.out.println("This is default");}
	Teacher(String n, long p){
		name=n;
		phone=p;}
void display(){
	
	System.out.println("Name: :"+name);
	System.out.println("Gender: :"+gender);
System.out.println("Contact :"+phone);}}
public class test5{
	public static void main(String args[]){
		Teacher t1=new Teacher();
		t1.display();
		Teacher t2=new Teacher("Raima",32893289);
t2.display();}}