public class Stringop2  
{  
public static void main(String ar[])  
{  
String s="  Shahin  ";    
System.out.println(s);     
System.out.println(s.trim());
System.out.println(s.indexOf('h'));   
}  
}  