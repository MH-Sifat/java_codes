//
package B; 
class Balance{
String name;
double ba;
public Balance(String n, double b){
	this.name=n;
this.ba=b;}
public void display(){
	if(ba<0.0){
System.out.println(name+" "+ba);}}}
public class Account1{
	public static void main(String args[]){
		Balance current[]=new Balance[4];// memory space 
		current[0]=new Balance("Anika",5000.35);
		current[1]=new Balance("Samiha",3000.35);
		current[2]=new Balance("Kishore",2000.35);
		current[3]=new Balance("Rahim",-2400.35);
		for(int i=0;i<4;i++){
		current[i].display();}
		// for(class/type var: array_name)
			//{array_name.method()}
}}
		
		
		
		
		
		
