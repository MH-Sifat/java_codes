import java.util.Scanner;

public class Input {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		System.out.print("Enter a byte: ");
        byte byteValue = sc.nextByte();
        System.out.println("You entered byte: " + byteValue);

        System.out.print("Enter a short: ");
        short shortValue = sc.nextShort();
        System.out.println("You entered short: " + shortValue);

        System.out.print("Enter an integer: ");
        int intValue = sc.nextInt();
        System.out.println("You entered integer: " + intValue);

        System.out.print("Enter a long: ");
        long longValue = sc.nextLong();
        System.out.println("You entered long: " + longValue);

      
        System.out.print("Enter a double: ");
        double doubleValue = sc.nextDouble();
        System.out.println("You entered double: " + doubleValue);

        System.out.print("Enter a boolean (true/false): ");
        boolean booleanValue = sc.nextBoolean();
        System.out.println("You entered boolean: " + booleanValue);

      
        sc.nextLine(); //to avoid skipping the next input

        System.out.print("Enter a character: ");
        char charValue = sc.nextLine(); 
        System.out.println("You entered character: " + charValue);

      
        System.out.print("Enter a string: ");
        String stringValue = sc.nextLine();
        System.out.println("You entered string: " + stringValue);

     
    }
}
