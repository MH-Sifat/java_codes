import java.util.Scanner;

public class ParseIntExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter an integer: ");
        String input = scanner.nextLine(); // Read input as a String

        // Convert the String to an int using parseInt
        int intValue = Integer.parseInt(input);

        // Output the parsed integer
        System.out.println("You entered: " + intValue);

        // Close the scanner
        scanner.close();
    }
}
