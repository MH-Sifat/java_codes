//Setter and getter methods
// no return type for setter methods
//default
public class Box6{
	private double length;
	private double width;
	private double height;
public void setLength(double l){
	this.length=l;
}
public void setWidth(double w){
	this.width=w;
}
public void setHeight(double h){
	this.height=h;
}
public double getLength(){return this.length;}
public double getWidth(){return this.width;}
public double getHeight(){return this.height;}
public static void main(String args[]){
	Box6 b1= new Box6();
	b1.setLength(2.347);
	b1.setWidth(4.2);
	b1.setHeight(2.7);
	System.out.println("Length is : "+b1.getLength());
	System.out.println("Width is : "+b1.getWidth());
System.out.println("Height is : "+b1.getHeight());}}
	
	
