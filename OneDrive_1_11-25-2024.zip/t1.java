// task 01: take character inputs to read and see whether you have entered 
//a small or capital letter
//use charAt() and scanner class
import java.util.*;
import java.lang.*;
class t1{
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		char ch=sc.next().charAt(0);
		if(ch>='a' && ch<='z'){
		System.out.println("Small letter");}
		else if(ch>='A' && ch<='Z'){
		System.out.println("Capital letter");}
		else{
System.out.println("invalid");}}}
			
