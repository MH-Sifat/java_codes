//method overloading

class method4{
	public int area(int side){
	return side*side;}
	public int area(int side1, int side2){
	return side1*side2;}
	public static void main(String args[]){
		method4 m1=new method4();
		
		System.out.println("Area is"+m1.area(4));
			System.out.println("Area is"+m1.area(5,6));
}}
		
	