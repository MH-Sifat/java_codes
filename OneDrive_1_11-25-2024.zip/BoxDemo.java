import java.util.Scanner;
class Box{
double width;
double height;
double depth;}

public class BoxDemo{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
Box obj= new Box();
double volume;
obj.width= sc.nextDouble();
obj.height= sc.nextDouble();
obj.depth= sc.nextDouble();
volume= obj.width* obj.height * obj.depth;
System.out.println("Volume is:" +volume+" cubic units");
}}