import java.lang.*;
class string1{
	public static void main(String args[]){
		String s=new String("Hello");
		int age = 20;
		String message = "I am " + age + " years old";

		System.out.println(s);
		System.out.println(message);
}}
