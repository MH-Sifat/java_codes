class student{

private int id;//instance variable
private String name;
private double cgpa;
public void setId(int id){
this.id=id;}
public int getID(){
return this.id;}
}
public class demo{
	public static void main(String args[]){
		student s1=new student();
		s1.setId(123);
System.out.println(s1.getID());}}

