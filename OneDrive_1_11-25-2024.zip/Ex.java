// create a string object , store its indexes as integer and perform type 
//casting  to convert it into character within a class
import java.lang.*;
public class Ex{
public static void main(String args[]){
	String s6=new String("Java");
	String s5="Java Lab";
	int index1= s5.charAt(0);
	int index2= s6.charAt(2);// selecting indexes 
System.out.println("The character is :" +(char)index1);// type casting
System.out.println("The character is :" +(char)index2);
// trim(), indexOf() , equals(), compareTo(), toUpperCase(), to LowerCase()

}}



	

