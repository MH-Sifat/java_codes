//create two classes
import java.util.Scanner;
class Box2{
double length;
double height;
double depth;}
public class Task2{
public static void main(String args[]){
	Scanner sc= new Scanner(System.in);
	Box2 obj= new Box2();
	obj.length=sc.nextDouble();
	obj.height=sc.nextDouble();
	obj.depth=sc.nextDouble();
	double volume= obj.length*obj.height*obj.depth;
System.out.println(volume);
}}

	
