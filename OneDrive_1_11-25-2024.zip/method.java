class person{
    String name, gender, position;
    int ID, age;
    void setInfo(String n, String g, int id){
        name=n;
        gender=g;
        ID=id;
    }
    void displayInfo(){
        System.out.println("The name is "+name);
        System.out.println("The gender is "+gender);
        System.out.println("The ID is "+ID);

    }
}
public class method {
    public static void main(String args[])
    {
        person e1= new person();
        e1.setInfo("Raima Adhikary","female",2456);
        e1.displayInfo();
        // System.out.println("The name is "+e1.name);
        //System.out.println("The gender is "+e1.gender);
        //  System.out.println("The ID is "+e1.ID);


        person e2= new person();
        e2.setInfo("Raihan Islam","male",2356);
        e2.displayInfo();
        //System.out.println("The name is "+e2.name);
        //System.out.println("The gender is "+e2.gender);
        // System.out.println("The ID is "+e2.ID);

    }
}
