package encapsulation;
//main class 

public class encaptest{
	public static void main(String args[]){
		person6 p1=new person6();
		p1.setName("Rahman");
	p1.setAge(18);
	System.out.println(p1.getName());
		System.out.println(p1.getAge());
	
	}
}