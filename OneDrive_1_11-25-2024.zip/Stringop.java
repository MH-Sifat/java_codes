// trim(), indexOf() , equals(), compareTo(), toUpperCase(), to LowerCase()
import java.lang.*;
class Stringop{
	public static void main(String args[]){
		String s=" Saima Shahin ";
		String s2="Java Programming";
		String s3= new String("Hello");
		String s4= new String("Hello");
		//String s4=s3; // string reference
		System.out.println(s.trim());// trim method
		System.out.println(s.concat(s2));// concat() method
		System.out.println(s2.toUpperCase());
		System.out.println(s2.toLowerCase());
		if(s3==s4)
		{System.out.println("yes");}
	else
	{System.out.println("no");}
if(s3.equals(s4))
		{System.out.println("yes");}
	else	{System.out.println("no");}
}}
	
