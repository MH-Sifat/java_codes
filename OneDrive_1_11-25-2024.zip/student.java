class sample{

int id= 21;
float gpa= 3.23F;
String name="Raihan";
void display(){
System.out.println(id+" "+name+" "+gpa);}
}
public class student{
public static void main(String args[]){
sample s1= new sample();

s1.display();
}}