public class Method12{
	public static void main(String args[]){
		Method12 obj=new Method12();
	System.out.print("the sum: "+obj.add(12,34));}
	int s;// instance variable
	float d;// class variable
	float r;// class variable
	public int add(int a, int b){
		s= a+b;// a and b local variables
		return s;	
}}

// create div method and return the quotient
// add a condition if denominator is assigned as
// 0-> division is not possible
	
		
