// Parent class is Bank11 Class
// child classes - > SIBL - 4%, PBL- 5.3%
// same method
//mother class
class Bank11{
public float getROI(){
return 0;}
}
class SIBL extends Bank11{
public float getROI(){
return 4;}}
class PBL extends Bank11{
public float getROI(){
return 5.3f;}}
public class test1{
	public static void main(String args[]){
		SIBL s= new SIBL();
		PBL p=new PBL();
		System.out.println("Rate of interest: "+s.getROI()+" %");
		System.out.println("Rate of interest: "+p.getROI()+" %");
}}
		
		
		



