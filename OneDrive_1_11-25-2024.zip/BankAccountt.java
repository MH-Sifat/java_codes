class BankAccountt{
private int AccountNum;
private String AccountHolder;
private double balance;
public BankAccountt(){
	System.out.println("This is an Empty Account");
}
public BankAccountt(int Ac, String h, double b){
	System.out.println("Demo Account");
	this.AccountNum=Ac;
	this.AccountHolder=h;
	this.balance=b;	
}
public void setAccountNo(int AccountNum)
{ this.AccountNum=AccountNum;}
public void setAccountHolder(String AccountHolder)
{ this.AccountHolder=AccountHolder;}
public void setBalance(double balance){
this.balance=balance;}
public int getAccountNo(){
return AccountNum;}
public String getAccountHolder(){
return AccountHolder;}
public double getBalance(){
return balance;}
// transfer
// you can use classes as your primitive datatypes
public void sendMoney(BankAccountt a, double amount){
	this.balance=balance-amount;// for 1st account who sends
	a.balance= balance+amount;// for 2nd account who gets the money
	
}
public void showDetails(){
	System.out.println("Account Number is: "+AccountNum);
	System.out.println("Account holder name is: "+AccountHolder);
System.out.println("Balance is: "+balance);}}
	

 

