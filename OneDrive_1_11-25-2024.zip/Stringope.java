// string class's methods()
// isEmpty() equals of() index of() concat() substring() trim()
import java.lang.*;
import java.util.*;
public class Stringope{
public static void main(String args[]){
	String e=new String();//empty string object
	String r=new String("Hello! world");
	System.out.println(e.isEmpty());
	System.out.println(r.isEmpty());
	String o=new String(" java ");
	System.out.println(o.trim());
	System.out.println(r.substring(7));
	System.out.println(r.substring(0,5));
	// beginning index is inclusive and ending index is exclusive
	System.out.println(r.indexOf('w'));
	String t="Hi";
	String q="I am okay";
	System.out.println(t.indexOf('H'));
	// index of character from a specific index
	System.out.println(r.indexOf('l',2));
	
	//index of substring --> starting index of substring 
	System.out.println(r.indexOf("or"));
	
	System.out.println(t.concat(q));
	System.out.println(r.concat(t));
	
	
	
	

}}
		
	
