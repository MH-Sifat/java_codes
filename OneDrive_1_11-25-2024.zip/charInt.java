class charInt {

        public static void main(String[] args) {

            // Casting int to char
            char r;
            int i= 97;
            r= (char) i;
            System.out.println("Converted value "+i+" "+r);
        }}

