//encapsulation task
//default(Package -private) member class
package encapsulation;
public class person6{
	private String name;
	private int age;
	public void setName(String n){
	this.name=n;}
	public void setAge(int a){
	this.age=a;}
	public String getName(){ return name;}
	public int getAge(){return age;}
	
}
