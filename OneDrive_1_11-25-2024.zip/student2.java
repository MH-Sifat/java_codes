//Use of static keyword in java
// optional_modifier static data_type var_name=value;
//optional_modifier static return_type method_name()
class student2{
	int ID;
	String name;
	static String Section="O";
	static String Dept="Computer Science";
	static String Uni="AIUB";
	//reassignment 
	public student2(int i, String n){
		this.ID=i;
		this.name=n;
	}
	public void display(){
		System.out.println("ID is: "+ID);
		System.out.println("Name is: "+name);
		System.out.println("Section is: "+Section);
		System.out.println("Department is: "+Dept);
		System.out.println("University is: "+Uni);	
}}