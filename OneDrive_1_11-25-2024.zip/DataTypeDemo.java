public class DataTypeDemo
{
	boolean b1;
	char c1, c2;
	//float f1, f2, f3, f4;
	//double d1, d2, d3, d4;
	byte bt1, bt2;
	short s1, s2;
	int i1, i2;
	long l1, l2;
	public static void main(String args[ ])
{
		DataTypeDemo dtd = new DataTypeDemo( );

		System.out.println("Default Value of boolean: "+dtd.b1);
		System.out.println("Default Value of char: "+dtd.c1);
		dtd.c1 = '\u0000';
		System.out.println("Lowest Range of char: "+dtd.c1);
		dtd.c2 = '\uFFFF';
		System.out.println("Highest Range of char: "+dtd.c2);

		System.out.println("Default Value of byte: "+dtd.bt1);
		dtd.bt1 = -128;
		System.out.println("Lowest Range of byte: "+dtd.bt1);
		dtd.bt2 = 127;
		System.out.println("Highest Range of byte: "+dtd.bt2);
		//the next two lines will give error
		//dtd.bt1= -129;
		//dtd.bt2 = 128;
	}
}
