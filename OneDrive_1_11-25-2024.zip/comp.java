import java.lang.*;
class comp{
public static void main(String args[]){
	String s1="America";
	String s2="Banana";
	String s3=s1;
	
	System.out.println(s1.compareTo(s2));
	System.out.println(s1.compareTo(s3));
System.out.println(s2.compareTo(s1));}}
	
	
